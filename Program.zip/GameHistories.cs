﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    class GameHistories
    {
        List<List<string>> histories = new List<List<string>>();

        public void AddGame(List<string> game)
        {
            List<string> gme = new List<string>();
            foreach (string mv in game)
                gme.Add(mv);

            histories.Add(gme);
        }
    }
}
