﻿using System;
using System.Diagnostics;
using System.Linq;

namespace TicTacToe
{
    class Board
    {
        public enum Move { Sp, O, X};
        public enum Player {O, X, None };

        private Move[] board = Enumerable.Repeat(Move.Sp, 9).ToArray();
        Random rng = new Random(Guid.NewGuid().GetHashCode());
        /// <summary>
        /// Factory Function for Board class
        /// </summary>
        public static Board StartGame { get { return new Board(); } }

        public Board() { }
        public Board(Move[] brd)
        {
            Debug.Assert(brd.Length == 9);
            board = brd;
        }

        public Board(string input)
        {
            board = ReadBoard(input);           
        }

        public bool ValidMove(int row, int col, Move mv)
        {
            return ((row < 3 && row >= 0) &&
                   (col < 3 && col >= 0) &&
                   (mv != Move.Sp) &&
                   board[row * 3 + col] == Move.Sp) ;
        }

        public Move[] DoMove(int row, int col, Move mv)
        {
            Debug.Assert(row < 3 && row >= 0);
            Debug.Assert(col < 3 && col >= 0);
            Debug.Assert(mv != Move.Sp);
            int index = row * 3 + col;
            if (board[index] == Move.Sp)
            {
                board[index] = mv;
                return board;
            }

            throw new InvalidOperationException("Cannot place a move on an occupied board position");
        }

        public void DisplayBoard()
        {
            Console.WriteLine("");
            //row 1
            Console.Write("");
            WriteMove(board[0]);
            Console.Write("|");
            WriteMove(board[1]);
            Console.Write("|");
            WriteMove(board[2]);
            Console.WriteLine("");

            //row 2
            Console.Write("");
            WriteMove(board[3]);
            Console.Write("|");
            WriteMove(board[4]);
            Console.Write("|");
            WriteMove(board[5]);
            Console.WriteLine("");

            //row3
            Console.Write("");
            WriteMove(board[6]);
            Console.Write("|");
            WriteMove(board[7]);
            Console.Write("|");
            WriteMove(board[8]);
            Console.WriteLine("");
            Console.WriteLine("");
        }

        public void WriteMove(Move mv)
        {
            switch(mv)
            {
                case Move.Sp:
                    Console.Write(" ");
                    break;
                case Move.O:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("O");
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case Move.X:
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("X");
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                default:
                    throw new InvalidOperationException("Invalid Move Found");
            }
        }

        public string PrintBoard()
        {
            return String.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|",
                board[0], board[1], board[2], board[3], board[4], 
                board[5], board[6], board[7], board[8]);
        }

        public static Move[] ReadBoard(string input)
        {
            var moves = input.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            Debug.Assert(moves.Length == 9);
            return moves.Select(mv => CreateMove(mv)).ToArray();
        }

        private static Move CreateMove(string mv)
        {
            if (mv == " ") return Move.Sp;
            else if (mv == "O") return Move.O;
            else return Move.X;
        }

        public bool IsTie()
        {
            int nspaces = board.Where(i => i == Move.Sp).Count();
            return (nspaces == 0) &&
                   (!Winner(Board.Player.O)) &&
                   (!Winner(Board.Player.X));
        }

        public  bool Winner(Player pl)
        {
            var Sym = pl == Player.O ? Move.O : Move.X;
            // tic tac toe board layout
            // 0 | 1 | 2
            // 3 | 4 | 5
            // 6 | 7 | 8
            //is player a winner?
            //check for complete rows
            if (board[0] == Sym && board[1] == Sym && board[2] == Sym) return true;
            if (board[3] == Sym && board[4] == Sym && board[5] == Sym) return true;
            if (board[6] == Sym && board[7] == Sym && board[8] == Sym) return true;
            //check for complete columns
            if (board[0] == Sym && board[3] == Sym && board[6] == Sym) return true;
            if (board[1] == Sym && board[4] == Sym && board[7] == Sym) return true;
            if (board[2] == Sym && board[5] == Sym && board[8] == Sym) return true;
            //check for diagonals
            if (board[0] == Sym && board[4] == Sym && board[8] == Sym) return true;
            if (board[2] == Sym && board[4] == Sym && board[6] == Sym) return true;

            return false;
        }

        internal int RandomMove()
        {
            int nspaces = board.Where(i => i == Move.Sp).Count();
            int n = rng.Next(nspaces);
            for(int i = 0; i < 9; i++)
            {
                // find nth space on board
                if (board[i] == Move.Sp)
                {                    
                    if (n == 0)
                        return i;
                    n--;
                }
            }
            return -1;
        }
    }
}
